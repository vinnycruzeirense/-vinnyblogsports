
PASSO A PASSO PARA PUBLICAR SEU SITE 'VINNY BLOGSPORTS' GRATUITAMENTE:

1. Acesse https://github.com e crie uma conta gratuita (caso não tenha).

2. Crie um repositório com o nome: vinnyblogsports

3. Envie o arquivo 'index.html' para esse repositório.

4. Vá em: Settings > Pages > selecione a branch 'main' e a pasta '/root', clique em 'Save'.

5. Em alguns segundos, seu site estará no ar com o link:
   https://SEUNOME.github.io/vinnyblogsports

Substitua 'SEUNOME' pelo seu nome de usuário do GitHub.

Pronto! Você agora tem um site com domínio gratuito.
